export const environment = {
  production: false,
  apiBaseUrl: 'http://localhost:9090' // Example
};
